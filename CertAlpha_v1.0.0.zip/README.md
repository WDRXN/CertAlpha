# CertAlpha

Forge & transplant Authenticode certificates between Windows PE binaries
(`.exe` / `.dll`): extract a certificate from a donor, inspect its X.509
details, graft it into a target application, verify the result offline, or
strip signatures entirely.

- Python ≥ 3.8, **standard library only**
- Offline: no network, no subprocess, no persistence, no auto-execution
- Risk-gated: `inject` refuses to run without `--ack-authorized`
- Honest by design: `verify` tells you when a transplanted signature is
  cryptographically invalid (it always is — see below)

## Quick start

```bash
python -m certalpha inspect  {{DONOR_PE}}
python -m certalpha extract  {{DONOR_PE}} -o ./extracted
python -m certalpha inject   {{DONOR_PE}} {{TARGET_PE}} -o {{OUTPUT_PE}} --ack-authorized
python -m certalpha verify   {{OUTPUT_PE}}
python tests/selftest.py
```

## Read this

A transplanted cert is **not** a valid signature — Authenticode hashes the
file body, so the stored digest mismatches on any other binary. It only
fools naive checks (cert presence / unverified signer string); `signtool`,
SmartScreen and chain validation reject it. Valid signatures require the
private key (`signtool sign /f your_cert.pfx`).

**Authorized testing only.** See `usage.md` for the full risk alert,
command reference, error contract, and manifest details.
